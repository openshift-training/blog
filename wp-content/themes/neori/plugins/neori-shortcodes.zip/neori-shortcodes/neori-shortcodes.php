<?php

/*
Plugin Name: Neori Shortcodes
Plugin URI: http://litmotion.net
Description: Bunch of shortcodes.
Version: 1.0
Author: litMotion
*/



function neori_carousel() {

	ob_start();
	get_template_part( 'template-parts/carousel' );
	return ob_get_clean();

}

add_shortcode( 'carousel', 'neori_carousel' );



function neori_slice_type1() {

	ob_start();
	get_template_part( 'template-parts/slices/type1' );
	return ob_get_clean();

}

add_shortcode( 'slice_type1', 'neori_slice_type1' );



function neori_slice_type2() {

	ob_start();
	get_template_part( 'template-parts/slices/type2' );
	return ob_get_clean();

}

add_shortcode( 'slice_type2', 'neori_slice_type2' );



function neori_slice_type3() {

	ob_start();
	get_template_part( 'template-parts/slices/type3' );
	return ob_get_clean();

}

add_shortcode( 'slice_type3', 'neori_slice_type3' );



function neori_slice_type4() {

	ob_start();
	get_template_part( 'template-parts/slices/type4' );
	return ob_get_clean();

}

add_shortcode( 'slice_type4', 'neori_slice_type4' );



function neori_slice_type5() {

	ob_start();
	get_template_part( 'template-parts/slices/type5' );
	return ob_get_clean();

}

add_shortcode( 'slice_type5', 'neori_slice_type5' );



function neori_slice_type6() {

	ob_start();
	get_template_part( 'template-parts/slices/type6' );
	return ob_get_clean();

}

add_shortcode( 'slice_type6', 'neori_slice_type6' );



function neori_slice_type7() {

	ob_start();
	get_template_part( 'template-parts/slices/type7' );
	return ob_get_clean();

}

add_shortcode( 'slice_type7', 'neori_slice_type7' );

?>
